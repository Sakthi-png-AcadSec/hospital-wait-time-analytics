/*
Project: Hospital Wait-Time Analytics
Platform: Microsoft SQL Server 2019+ (uses CREATE OR ALTER VIEW and PERCENTILE_CONT)
Run in SSMS. This creates the database and an import-ready fact table.
Important: Import visits_for_sql.csv locally; never commit row-level data publicly.
*/
IF DB_ID(N'HospitalWaitAnalytics') IS NULL
    EXEC('CREATE DATABASE HospitalWaitAnalytics');
GO
USE HospitalWaitAnalytics;
GO

IF OBJECT_ID(N'dbo.FactVisit', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.FactVisit
    (
        VisitKey BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_FactVisit PRIMARY KEY,
        SourceVisitID VARCHAR(40) NOT NULL,
        VisitDate DATE NOT NULL,
        DoctorTypeName VARCHAR(30) NOT NULL,
        EntryTime TIME(0) NOT NULL,
        PostConsultationTime TIME(0) NULL,
        CompletionTime TIME(0) NULL,
        WaitingMinutes DECIMAL(10,2) NOT NULL,
        EntryHour TINYINT NOT NULL,
        DayOfWeekName VARCHAR(12) NOT NULL,
        HourlyLoad INT NULL,
        WaitClass VARCHAR(20) NOT NULL,
        LoadDtm DATETIME2(0) NOT NULL CONSTRAINT DF_FactVisit_LoadDtm DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_FactVisit_WaitingMinutes CHECK (WaitingMinutes >= 0),
        CONSTRAINT CK_FactVisit_EntryHour CHECK (EntryHour BETWEEN 0 AND 23),
        CONSTRAINT CK_FactVisit_HourlyLoad CHECK (HourlyLoad IS NULL OR HourlyLoad >= 0),
        CONSTRAINT CK_FactVisit_WaitClass CHECK (WaitClass IN ('Short Wait','Moderate Wait','Long Wait'))
    );

    CREATE INDEX IX_FactVisit_VisitDate ON dbo.FactVisit(VisitDate) INCLUDE (WaitingMinutes, DoctorTypeName, EntryHour, WaitClass);
    CREATE INDEX IX_FactVisit_DoctorType_Date ON dbo.FactVisit(DoctorTypeName, VisitDate) INCLUDE (WaitingMinutes, EntryHour, WaitClass);
    CREATE INDEX IX_FactVisit_EntryHour ON dbo.FactVisit(EntryHour) INCLUDE (WaitingMinutes, DoctorTypeName);
END;
GO

/* Optional: run after importing the CSV to confirm that data arrived. */
SELECT COUNT_BIG(*) AS LoadedRows,
       MIN(VisitDate) AS FirstVisitDate,
       MAX(VisitDate) AS LastVisitDate,
       MIN(WaitingMinutes) AS MinimumWaitMinutes,
       MAX(WaitingMinutes) AS MaximumWaitMinutes
FROM dbo.FactVisit;
GO
