/* Reusable SQL Server analytical views for Power BI. */
USE HospitalWaitAnalytics;
GO

CREATE OR ALTER VIEW dbo.vw_WaitingKPI AS
WITH MedianValue AS
(
    SELECT DISTINCT
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY WaitingMinutes) OVER () AS MedianWaitMinutes
    FROM dbo.FactVisit
),
BaseValue AS
(
    SELECT COUNT_BIG(*) AS TotalVisits,
           AVG(CAST(WaitingMinutes AS DECIMAL(10,2))) AS MeanWaitMinutes,
           SUM(CASE WHEN WaitingMinutes > 45 THEN 1 ELSE 0 END) AS VisitsOver45Minutes,
           SUM(CASE WHEN WaitingMinutes > 60 THEN 1 ELSE 0 END) AS VisitsOver60Minutes
    FROM dbo.FactVisit
)
SELECT b.TotalVisits,
       CAST(b.MeanWaitMinutes AS DECIMAL(10,2)) AS MeanWaitMinutes,
       CAST(m.MedianWaitMinutes AS DECIMAL(10,2)) AS MedianWaitMinutes,
       b.VisitsOver45Minutes,
       CAST(100.0 * b.VisitsOver45Minutes / NULLIF(b.TotalVisits,0) AS DECIMAL(6,2)) AS LongWaitRatePct,
       b.VisitsOver60Minutes,
       CAST(100.0 * b.VisitsOver60Minutes / NULLIF(b.TotalVisits,0) AS DECIMAL(6,2)) AS Over60RatePct
FROM BaseValue b CROSS JOIN MedianValue m;
GO

CREATE OR ALTER VIEW dbo.vw_WaitByHour AS
WITH HourMedian AS
(
    SELECT DISTINCT EntryHour,
           PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY WaitingMinutes) OVER (PARTITION BY EntryHour) AS MedianWaitMinutes
    FROM dbo.FactVisit
),
HourAgg AS
(
    SELECT EntryHour, COUNT_BIG(*) AS Visits,
           AVG(CAST(WaitingMinutes AS DECIMAL(10,2))) AS MeanWaitMinutes,
           SUM(CASE WHEN WaitingMinutes > 45 THEN 1 ELSE 0 END) AS LongWaitVisits
    FROM dbo.FactVisit
    GROUP BY EntryHour
)
SELECT a.EntryHour, a.Visits,
       CAST(a.MeanWaitMinutes AS DECIMAL(10,2)) AS MeanWaitMinutes,
       CAST(m.MedianWaitMinutes AS DECIMAL(10,2)) AS MedianWaitMinutes,
       a.LongWaitVisits,
       CAST(100.0 * a.LongWaitVisits / NULLIF(a.Visits,0) AS DECIMAL(6,2)) AS LongWaitRatePct
FROM HourAgg a INNER JOIN HourMedian m ON a.EntryHour = m.EntryHour;
GO

CREATE OR ALTER VIEW dbo.vw_WaitByDoctor AS
WITH DoctorMedian AS
(
    SELECT DISTINCT DoctorTypeName,
           PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY WaitingMinutes) OVER (PARTITION BY DoctorTypeName) AS MedianWaitMinutes
    FROM dbo.FactVisit
),
DoctorAgg AS
(
    SELECT DoctorTypeName, COUNT_BIG(*) AS Visits,
           AVG(CAST(WaitingMinutes AS DECIMAL(10,2))) AS MeanWaitMinutes,
           SUM(CASE WHEN WaitingMinutes > 45 THEN 1 ELSE 0 END) AS LongWaitVisits
    FROM dbo.FactVisit
    GROUP BY DoctorTypeName
)
SELECT a.DoctorTypeName, a.Visits,
       CAST(100.0 * a.Visits / NULLIF(SUM(a.Visits) OVER (),0) AS DECIMAL(6,2)) AS VisitSharePct,
       CAST(a.MeanWaitMinutes AS DECIMAL(10,2)) AS MeanWaitMinutes,
       CAST(m.MedianWaitMinutes AS DECIMAL(10,2)) AS MedianWaitMinutes,
       a.LongWaitVisits,
       CAST(100.0 * a.LongWaitVisits / NULLIF(a.Visits,0) AS DECIMAL(6,2)) AS LongWaitRatePct
FROM DoctorAgg a INNER JOIN DoctorMedian m ON a.DoctorTypeName = m.DoctorTypeName;
GO

CREATE OR ALTER VIEW dbo.vw_WaitByDate AS
SELECT VisitDate,
       DATENAME(WEEKDAY, VisitDate) AS DayOfWeekName,
       COUNT_BIG(*) AS Visits,
       CAST(AVG(CAST(WaitingMinutes AS DECIMAL(10,2))) AS DECIMAL(10,2)) AS MeanWaitMinutes,
       SUM(CASE WHEN WaitingMinutes > 45 THEN 1 ELSE 0 END) AS LongWaitVisits,
       CAST(100.0 * SUM(CASE WHEN WaitingMinutes > 45 THEN 1 ELSE 0 END) / NULLIF(COUNT_BIG(*),0) AS DECIMAL(6,2)) AS LongWaitRatePct
FROM dbo.FactVisit
GROUP BY VisitDate;
GO

CREATE OR ALTER VIEW dbo.vw_WaitClassDistribution AS
SELECT WaitClass, COUNT_BIG(*) AS Visits,
       CAST(100.0 * COUNT_BIG(*) / NULLIF(SUM(COUNT_BIG(*)) OVER (),0) AS DECIMAL(6,2)) AS VisitSharePct,
       CAST(AVG(CAST(WaitingMinutes AS DECIMAL(10,2))) AS DECIMAL(10,2)) AS MeanWaitMinutes
FROM dbo.FactVisit
GROUP BY WaitClass;
GO

CREATE OR ALTER VIEW dbo.vw_WaitByDayAndHour AS
SELECT VisitDate, EntryHour, DoctorTypeName,
       COUNT_BIG(*) AS Visits,
       CAST(AVG(CAST(WaitingMinutes AS DECIMAL(10,2))) AS DECIMAL(10,2)) AS MeanWaitMinutes,
       SUM(CASE WHEN WaitingMinutes > 45 THEN 1 ELSE 0 END) AS LongWaitVisits
FROM dbo.FactVisit
GROUP BY VisitDate, EntryHour, DoctorTypeName;
GO
