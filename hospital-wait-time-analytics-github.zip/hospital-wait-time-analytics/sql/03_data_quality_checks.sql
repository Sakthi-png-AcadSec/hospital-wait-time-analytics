/* Run after data import. Review exceptions; do not blindly delete rows. */
USE HospitalWaitAnalytics;
GO

-- 1. Row count and date coverage
SELECT COUNT_BIG(*) AS TotalRows,
       COUNT(DISTINCT SourceVisitID) AS DistinctSourceIDs,
       MIN(VisitDate) AS FirstDate,
       MAX(VisitDate) AS LastDate
FROM dbo.FactVisit;
GO

-- 2. Nulls in required fields (constraints should prevent most of these)
SELECT
    SUM(CASE WHEN SourceVisitID IS NULL OR LTRIM(RTRIM(SourceVisitID)) = '' THEN 1 ELSE 0 END) AS MissingSourceVisitID,
    SUM(CASE WHEN DoctorTypeName IS NULL OR LTRIM(RTRIM(DoctorTypeName)) = '' THEN 1 ELSE 0 END) AS MissingDoctorType,
    SUM(CASE WHEN WaitingMinutes IS NULL THEN 1 ELSE 0 END) AS MissingWaitingMinutes
FROM dbo.FactVisit;
GO

-- 3. Duplicate source IDs. These may be legitimate if Patient ID is not a unique visit ID.
SELECT SourceVisitID, COUNT_BIG(*) AS RowCount
FROM dbo.FactVisit
GROUP BY SourceVisitID
HAVING COUNT_BIG(*) > 1
ORDER BY RowCount DESC;
GO

-- 4. Potentially suspicious durations and time sequence issues.
SELECT VisitKey, SourceVisitID, VisitDate, EntryTime, PostConsultationTime,
       CompletionTime, WaitingMinutes
FROM dbo.FactVisit
WHERE WaitingMinutes < 0
   OR WaitingMinutes > 24 * 60
   OR (PostConsultationTime IS NOT NULL AND PostConsultationTime < EntryTime)
   OR (CompletionTime IS NOT NULL AND PostConsultationTime IS NOT NULL AND CompletionTime < PostConsultationTime)
ORDER BY VisitDate, EntryTime;
GO

-- 5. Check consistency between the stored category and defined thresholds.
SELECT COUNT_BIG(*) AS CategoryMismatchRows
FROM dbo.FactVisit
WHERE (WaitingMinutes <= 20 AND WaitClass <> 'Short Wait')
   OR (WaitingMinutes > 20 AND WaitingMinutes <= 45 AND WaitClass <> 'Moderate Wait')
   OR (WaitingMinutes > 45 AND WaitClass <> 'Long Wait');
GO

-- 6. Dashboard reconciliation by doctor type.
SELECT DoctorTypeName, COUNT_BIG(*) AS Visits,
       CAST(AVG(CAST(WaitingMinutes AS DECIMAL(10,2))) AS DECIMAL(10,2)) AS MeanWaitMinutes,
       SUM(CASE WHEN WaitingMinutes > 45 THEN 1 ELSE 0 END) AS LongWaitVisits
FROM dbo.FactVisit
GROUP BY DoctorTypeName
ORDER BY Visits DESC;
GO
