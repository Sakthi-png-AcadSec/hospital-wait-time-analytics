# Hospital Wait-Time Analytics — SQL Server, Power BI & Python

An end-to-end healthcare operations analytics portfolio project. It combines SQL Server data modelling and analytical views, data-quality checks, a Power BI dashboard specification, DAX measures, and an exploratory machine-learning baseline.

## Business question
How do recorded waiting-time patterns vary by arrival hour, date, and doctor type, and how could an operations team use those patterns to investigate bottlenecks?

## Dataset and interpretation
The source workbook contains 29,998 outpatient visit records dated 1–13 November 2019. The hospital is unnamed. The recorded waiting-time field is treated as the supplied `Waiting Time` value; the accompanying academic analysis defines the interval from Entry Time to Post-Consultation Time, which may include consultation duration. Findings apply only to this dataset and period and should not be described as current hospital performance.

**Responsible sharing:** do not commit the original workbook or row-level data to a public repository without explicit permission. This repository includes aggregate-only demo tables. The raw workbook and generated row-level files are excluded by `.gitignore`.

## What is included
- `sql/01_create_schema.sql` — creates the SQL Server database and import-ready fact table.
- `sql/02_analytical_views.sql` — reusable KPI, hourly, doctor-type, daily, wait-class, and day/hour views.
- `sql/03_data_quality_checks.sql` — checks for duplicates, missing fields, suspicious durations, category mismatches, and reconciliation.
- `powerbi/measures.dax` — core Power BI measures.
- `powerbi/dashboard_build_guide.md` — step-by-step instructions to build and validate the interactive report.
- `powerbi/dashboard_preview.png` / `.pdf` — static design preview, not a native PBIX file.
- `data/derived_aggregates/powerbi_aggregate_tables.xlsx` — aggregate-only workbook for a quick Power BI demo.
- `python/prepare_data.py` — locally prepares SQL-ready rows and aggregate outputs.
- `python/train_baseline.py` — optional exploratory classification baseline.

## Quick start

### 1. Install dependencies
```bash
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Place the source workbook locally
Create `data/raw/` and put `Hospital_patient_waiting_data.xlsx` in that folder. Do not commit the source workbook.

### 3. Run preprocessing
```bash
python python/prepare_data.py --input data/raw/Hospital_patient_waiting_data.xlsx --output data/processed
python python/train_baseline.py --input data/processed/visits_for_analysis.csv --output outputs/ml
```

The `data/processed/` and `outputs/` folders are ignored by Git because they may contain row-level records.

### 4. Create the SQL database
Open SQL Server Management Studio and run, in order:
1. `sql/01_create_schema.sql`
2. Import `data/processed/visits_for_sql.csv` into `dbo.FactVisit` (omit generated `VisitKey` and `LoadDtm` columns).
3. `sql/02_analytical_views.sql`
4. `sql/03_data_quality_checks.sql`

### 5. Build the Power BI report
Follow `powerbi/dashboard_build_guide.md`. For a quick demo, import the aggregate workbook; for full cross-filtering and drill-through, connect to SQL Server and use the fact table. DAX measures must be created in Power BI Desktop; a native `.pbix` file is not included because it needs to be saved and validated in Power BI Desktop.

## Suggested portfolio report pages
1. **Executive Overview:** visit volume, mean/median wait, long-wait rate, over-60-minute visits.
2. **Demand Patterns:** waiting-time and visit-volume patterns by hour and date.
3. **Doctor Operations:** doctor-type comparison and waiting-time category distribution.
4. **Data Quality & Model Review:** data-quality findings, model metrics, limitations, and recommendations.

## Suggested resume bullet — use after completing the build
**Hospital Wait-Time Analytics | SQL Server, Power BI, Python** — Analyzed approximately 30,000 outpatient visit records; developed SQL analytical views and data-quality checks, and built a Power BI dashboard specification to investigate waiting-time patterns by hour, date, and doctor type.

Only claim that you built an interactive Power BI dashboard after creating and validating the `.pbix` yourself. Add quantified impact only if you measured it; this project analyzes historical data and does not establish real-world operational savings.

## Limitations
- Only 13 days of historical data from an unnamed hospital.
- Waiting-time definition may include consultation duration.
- No causal claim that staffing or a specific intervention will reduce waiting time.
- The ML model is exploratory and should not be used for patient-level decisions.
- Same-hour patient load may include later arrivals in that hour, which creates leakage risk for real-time prediction.
- This is a portfolio analytics project, not a deployed healthcare product.
