# Findings from the supplied academic report

These are report-reported findings, not a fresh independent validation:
- 29,998 visits over 1–13 November 2019.
- Mean recorded wait: 38.9 minutes; median: 26.3 minutes.
- 18.0% waited more than 60 minutes.
- Average waits peaked for arrivals 09:00–09:59 (53.0 minutes); the broader morning period 08:00–10:59 showed elevated waits.
- Anchor doctors accounted for 73.0% of visits and had a mean recorded wait of 42.9 minutes, versus 28.5 for Locum and 26.7 for Floating.
- Gaussian Naive Bayes accuracy was reported as 41.65% (80:20), 41.76% (70:30), and 41.35% (60:40), versus a 38.62% majority-class baseline.
- Moderate-wait recall was only about 3%, so aggregate accuracy alone is misleading.

Caveats: unnamed hospital, only 13 days, waiting-time definition may include consultation time, hourly load can leak later arrivals, and associations do not establish causes. Do not claim that the model is production-ready.
