# Data dictionary

| Field | Definition | Notes |
|---|---|---|
| SourceVisitID | Source workbook's Patient ID | Pseudonymous identifier; do not publish row-level records |
| VisitDate | Date of visit | Source coverage is 1–13 Nov 2019 |
| DoctorTypeName | ANCHOR, LOCUM, FLOATING | Category from source workbook |
| EntryTime | Entry/arrival time | Used to derive arrival hour |
| PostConsultationTime | Timestamp after consultation | Used in recorded wait definition; post-arrival outcome |
| CompletionTime | Visit completion time | Not a predictor for arrival-time model |
| WaitingMinutes | Waiting Time converted to minutes | Entry Time to Post-Consultation Time; may include consultation time |
| EntryHour | Integer hour of arrival | 0–23 |
| DayOfWeekName | Day name from VisitDate | Calendar-derived |
| HourlyLoad | Number of visits in same date-hour group | Retrospective feature; can include later arrivals in that hour |
| WaitClass | Short (<=20), Moderate (>20 and <=45), Long (>45) | Thresholds chosen for the academic baseline |

## Quality checks
- Verify row count and missing values.
- Compare recorded Waiting Time with Post-Consultation Time minus Entry Time.
- Check for negative waiting times and duplicate source IDs.
- Inspect extreme waits rather than automatically deleting them.
