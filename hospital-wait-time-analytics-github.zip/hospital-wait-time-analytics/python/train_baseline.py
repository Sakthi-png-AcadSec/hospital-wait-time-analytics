"""Reproduce a Naive Bayes baseline. This is for learning/portfolio use, not clinical deployment."""
import argparse, json
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--output", default="outputs/ml")
    args = p.parse_args()
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.input)
    # Same-hour load is retained only to reproduce the academic baseline; it can include future arrivals.
    X = df[["EntryHourDecimal", "DayOfWeekName", "HourlyLoad", "Doctor Type"]]
    y = df["WaitClass"].astype(str)
    numeric = ["EntryHourDecimal", "HourlyLoad"]
    categorical = ["DayOfWeekName", "Doctor Type"]
    pre = ColumnTransformer([
        ("num", StandardScaler(), numeric),
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), categorical)
    ])
    rows = []
    for test_size in [0.2, 0.3, 0.4]:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y)
        model = Pipeline([("preprocess", pre), ("classifier", GaussianNB())])
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        labels = ["Short Wait", "Moderate Wait", "Long Wait"]
        rows.append({
            "TrainTestSplit": f"{int((1-test_size)*100)}:{int(test_size*100)}",
            "Accuracy": accuracy_score(y_test, pred),
            "WeightedPrecision": precision_score(y_test, pred, average="weighted", zero_division=0),
            "WeightedRecall": recall_score(y_test, pred, average="weighted", zero_division=0),
            "WeightedF1": f1_score(y_test, pred, average="weighted", zero_division=0),
            "MajorityBaseline": y_test.value_counts(normalize=True).max(),
            "ClassReport": classification_report(y_test, pred, labels=labels, output_dict=True, zero_division=0),
            "ConfusionMatrix": confusion_matrix(y_test, pred, labels=labels).tolist()
        })
    flat = [{k:v for k,v in row.items() if k not in ("ClassReport","ConfusionMatrix")} for row in rows]
    pd.DataFrame(flat).to_csv(out/"model_metrics.csv", index=False)
    (out/"model_details.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(pd.DataFrame(flat).to_string(index=False))
    print("Important: evaluate class-level recall and compare with baseline; do not report accuracy alone.")

if __name__ == "__main__":
    main()
