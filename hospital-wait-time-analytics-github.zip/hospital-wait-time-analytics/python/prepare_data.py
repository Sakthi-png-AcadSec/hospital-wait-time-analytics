"""Prepare the hospital waiting-time workbook for SQL and Power BI.
Only aggregate outputs should be committed. Row-level outputs are local and gitignored.
"""
import argparse
from pathlib import Path
import pandas as pd
import numpy as np

def seconds(value):
    if pd.isna(value): return np.nan
    if hasattr(value, "hour"):
        return value.hour * 3600 + value.minute * 60 + value.second
    if isinstance(value, (int, float, np.integer, np.floating)):
        return float(value) * 86400
    parts = str(value).strip().split(":")
    if len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    raise ValueError(f"Unrecognised time value: {value!r}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to local source Excel workbook")
    parser.add_argument("--output", default="data/processed")
    args = parser.parse_args()
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_excel(args.input)
    df.columns = [str(c).strip() for c in df.columns]
    required = ["Date", "Patient ID", "Doctor Type", "Entry Time",
                "Post-Consultation Time", "Completion Time", "Waiting Time"]
    missing = sorted(set(required) - set(df.columns))
    if missing: raise ValueError(f"Missing expected columns: {missing}")
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    for col in ["Entry Time", "Post-Consultation Time", "Completion Time", "Waiting Time"]:
        df[col + "_seconds"] = df[col].map(seconds)
    df["WaitingMinutes"] = df["Waiting Time_seconds"] / 60
    df["EntryHourDecimal"] = df["Entry Time_seconds"] / 3600
    df["EntryHour"] = (df["Entry Time_seconds"] // 3600).astype(int)
    df["DayOfWeekName"] = df["Date"].dt.day_name()
    df["HourlyLoad"] = df.groupby([df["Date"].dt.date, "EntryHour"])["Patient ID"].transform("count")
    df["WaitClass"] = pd.cut(df["WaitingMinutes"], [-np.inf, 20, 45, np.inf],
                             labels=["Short Wait", "Moderate Wait", "Long Wait"]).astype(str)
    if df["Date"].isna().any(): raise ValueError("Some Date values could not be parsed.")
    if df["WaitingMinutes"].isna().any() or (df["WaitingMinutes"] < 0).any():
        raise ValueError("Missing or negative waiting times detected.")
    # Validate recorded interval definition; small tolerance allows time precision differences.
    expected = (df["Post-Consultation Time_seconds"] - df["Entry Time_seconds"]) / 60
    print("Rows:", len(df))
    print("Missing values by column:\n", df[required].isna().sum().to_string())
    print("Rows with >0.02-minute interval mismatch:", int(((df["WaitingMinutes"] - expected).abs() > .02).sum()))
    sql_df = pd.DataFrame({
        "SourceVisitID": df["Patient ID"].astype(str),
        "VisitDate": df["Date"].dt.strftime("%Y-%m-%d"),
        "DoctorTypeName": df["Doctor Type"].astype(str).str.upper(),
        "EntryTime": df["Entry Time_seconds"].map(lambda x: f"{int(x//3600):02d}:{int(x%3600//60):02d}:{int(x%60):02d}"),
        "PostConsultationTime": df["Post-Consultation Time_seconds"].map(lambda x: f"{int(x//3600):02d}:{int(x%3600//60):02d}:{int(x%60):02d}"),
        "CompletionTime": df["Completion Time_seconds"].map(lambda x: f"{int(x//3600):02d}:{int(x%3600//60):02d}:{int(x%60):02d}"),
        "WaitingMinutes": df["WaitingMinutes"].round(2),
        "EntryHour": df["EntryHour"],
        "DayOfWeekName": df["DayOfWeekName"],
        "HourlyLoad": df["HourlyLoad"],
        "WaitClass": df["WaitClass"],
    })
    sql_df.to_csv(out / "visits_for_sql.csv", index=False)
    ml_cols = ["WaitingMinutes", "EntryHourDecimal", "EntryHour", "DayOfWeekName",
               "HourlyLoad", "Doctor Type", "WaitClass"]
    df[ml_cols].to_csv(out / "visits_for_analysis.csv", index=False)
    agg_dir = out / "aggregates"; agg_dir.mkdir(exist_ok=True)
    df.groupby("EntryHour").agg(Visits=("Patient ID","size"),
        MeanWaitMinutes=("WaitingMinutes","mean"), MedianWaitMinutes=("WaitingMinutes","median"),
        LongWaitVisits=("WaitClass", lambda s: (s=="Long Wait").sum())).reset_index().round(2).to_csv(agg_dir/"waiting_by_hour.csv", index=False)
    df.groupby("Doctor Type").agg(Visits=("Patient ID","size"),
        MeanWaitMinutes=("WaitingMinutes","mean"), MedianWaitMinutes=("WaitingMinutes","median"),
        LongWaitVisits=("WaitClass", lambda s: (s=="Long Wait").sum())).reset_index().round(2).to_csv(agg_dir/"waiting_by_doctor.csv", index=False)
    df.groupby(["Date","DayOfWeekName"]).agg(Visits=("Patient ID","size"),
        MeanWaitMinutes=("WaitingMinutes","mean"), MedianWaitMinutes=("WaitingMinutes","median"),
        LongWaitVisits=("WaitClass", lambda s: (s=="Long Wait").sum())).reset_index().round(2).to_csv(agg_dir/"waiting_by_day.csv", index=False)
    df.groupby("WaitClass", observed=False).agg(Visits=("Patient ID","size"),
        MeanWaitMinutes=("WaitingMinutes","mean")).reset_index().round(2).to_csv(agg_dir/"waiting_by_class.csv", index=False)
    print("Wrote local row-level outputs and aggregate Power BI tables to", out)

if __name__ == "__main__":
    main()
